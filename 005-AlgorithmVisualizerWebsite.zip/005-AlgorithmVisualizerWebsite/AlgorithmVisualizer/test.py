# from flask import Flask, render_template
# import plotly.graph_objs as go
# import pandas as pd
# app = Flask(__name__)
# @app.route('/')
# def index():
#     column_headers = ['Software Engineering score', 'Machine Learning score', 'DBMS score', 'Elective 1 score', 'Elective 2 score']
#     col_vals = [72, 72, 74, 88, 69]

#     # Create a DataFrame with the given data
#     df = pd.DataFrame({'Subjects': column_headers, 'Scores': col_vals})

#     # Normalize the data to create the stacked area chart
#     df['Normalized_Scores'] = df['Scores'] / df['Scores'].sum()
#     df['Normalized_Scores'] = df['Normalized_Scores'].cumsum()

#     # Create a stacked area chart using Plotly
#     fig = go.Figure()
#     for i, subject in enumerate(df['Subjects']):
#         fig.add_trace(go.Scatter(x=[0, 1], y=[0, df['Normalized_Scores'][i]], fill='tozeroy', mode='none', name=subject))

#     fig.update_layout(title='Stacked Area Chart with Normalized Values')

#     chart_div = fig.to_html(full_html=False)

#     return render_template('fff.html', chart_div=chart_div)

# if __name__ == '__main__':
#     app.run(debug=True)

from flask import Flask, render_template
import plotly.graph_objects as go

app = Flask(__name__)

@app.route('/')
def index():
    x = ['Software Engineering score', 'Machine Learning score', 'DBMS score', 'Elective 1 score', 'Elective 2 score']
    y = [72, 72, 74, 88, 69]

    

    return render_template('fff.html', x=x ,y=y)

if __name__ == '__main__':
    app.run(debug=True)
